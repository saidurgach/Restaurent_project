import Dosa from '../image/dosa.jpg'
import Chola from '../image/chhola.jpg'
import Idli from '../image/idli.jpg'
import MasalaDosa from '../image/masala.jpg'
import Paneer from '../image/paneer.jpg'
import Gujarati from '../image/gujrati.jpeg'
import Chapathi from '../image/chapathi.jpg' 
import Mushroompulao from '../image/mushroom_pulao.jpg'
import Paneer_butter_masala from '../image/paneer_butter_masala.jpg'
import Parota from '../image/parota.jpg'
import Veg_Thaali from '../image/veg_thaali.jpg'
import Veg_pulao from '../image/veg_pulao.jpg'
import Poori from '../image/poori.jpg'
import Tomato_rice from '../image/tomatorice.jpg'
import Veg_noodles from '../image/veg_noodles.jpg'




export const MenuList=[
    {
        id:1,
    name:'Dosa',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Dosa,
     Price:100

},
{
    id:2,
    name:'Chola',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Chola,
     Price:50

},
{
    id:3,
    name:'Idli',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Idli,
     Price:100

},
{
    id:4,
    name:'MasalaDosa',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:MasalaDosa,
     Price:100

},
{
    id:5,
    name:'Paneer',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Paneer,
     Price:200

},
{
    id:6,
    name:'Gujarati',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Gujarati,
     Price:300
     

},

{
    id:7,
    name:'Veg_pulao',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Veg_pulao,
     Price:100
     

},
{
    id:8,
    name:'Mushroompulao',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Mushroompulao,
     Price:200
     

},


{
    id:9,
    name:'Paneer_butter_masala',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Paneer_butter_masala,
     Price:150
     

},
{
    id:10,
    name:'Veg_Thaali',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Veg_Thaali,
     Price:300
     

},
{
    id:11,
    name:'Chapathi',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Chapathi,
     Price:50
     

},
{
    id:12,
    name:'Veg_noodles',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Veg_noodles,
     Price:100
     

},
{
    id:13,
    name:'Parota',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Parota,
     Price:100
     

},
{
    id:14,
    name:'Poori',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Poori,
     Price:100
     

},
{
    id:15,
    name:'Tomato_rice',
    Description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys.',
     image:Tomato_rice,
     Price:150
     

},



]